ZeroTier One SDK - Android JNI Wrapper
=====


Building
-----

Reqires:

* JDK
* ANT
* Android NDK

Required Environment Variables:

* NDK\_BUILD\_LOC - Path do the ndk-build script in the Android NDK
* ANDROID\_PLATFORM - path to the directory android.jar lives (on Windows: C:\Users\<username>\AppData\Local\Android\sdk\platforms\android-21)
